#include "mouse.h"
#include "../../../Kernel/kernel.h"

MOUSE_STATE current_mouse = {512, 384, FALSE, FALSE};

/* The Classic Windows 95 Arrow Cursor (12x19 pixels) 
   0 = Transparent, 1 = White, 2 = Black Border
*/
unsigned char win95_cursor[12 * 19] = {
    2,2,0,0,0,0,0,0,0,0,0,0,
    2,1,2,0,0,0,0,0,0,0,0,0,
    2,1,1,2,0,0,0,0,0,0,0,0,
    2,1,1,1,2,0,0,0,0,0,0,0,
    2,1,1,1,1,2,0,0,0,0,0,0,
    2,1,1,1,1,1,2,0,0,0,0,0,
    2,1,1,1,1,1,1,2,0,0,0,0,
    2,1,1,1,1,1,1,1,2,0,0,0,
    2,1,1,1,1,1,1,1,1,2,0,0,
    2,1,1,1,1,1,1,1,1,1,2,0,
    2,1,1,1,1,1,2,2,2,2,2,2,
    2,1,1,2,1,1,2,0,0,0,0,0,
    2,1,2,0,2,1,1,2,0,0,0,0,
    2,2,0,0,2,1,1,2,0,0,0,0,
    0,0,0,0,0,2,1,1,2,0,0,0,
    0,0,0,0,0,2,1,1,2,0,0,0,
    0,0,0,0,0,0,2,2,0,0,0,0
};

void draw_mouse_cursor(int x, int y) {
    for (int row = 0; row < 19; row++) {
        for (int col = 0; col < 12; col++) {
            unsigned char pixel = win95_cursor[row * 12 + col];
            uint32_t color;
            
            if (pixel == 0) continue; // Skip transparency
            if (pixel == 1) color = 0xFFFFFF; // White
            if (pixel == 2) color = 0x000000; // Black border
            
            int target_x = x + col;
            int target_y = y + row;
            
            if (target_x < WIDTH && target_y < HEIGHT) {
                LFB[target_y * WIDTH + target_x] = color;
            }
        }
    }
}

// Note: mouse_init and interrupt logic would go here to talk to Hardware