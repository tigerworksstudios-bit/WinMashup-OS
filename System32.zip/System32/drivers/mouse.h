#ifndef MOUSE_H
#define MOUSE_H

#include "../win_types.h"

/* Mouse State Structure */
typedef struct {
    int x;
    int y;
    BOOL leftButton;
    BOOL rightButton;
} MOUSE_STATE;

/* Function Prototypes */
void mouse_init();               // Initialize the PS/2 Port
void mouse_wait(BYTE type);      // Wait for the mouse controller
void mouse_handler();            // Called when the mouse moves
void draw_mouse_cursor(int x, int y);

extern MOUSE_STATE current_mouse;

#endif