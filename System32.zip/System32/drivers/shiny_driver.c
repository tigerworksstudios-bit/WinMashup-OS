#include "shiny_driver.h"

/* Global list of drivers currently loaded in the mashup */
shiny_driver_t* driver_stack[256];
int loaded_driver_count = 0;

/* Registry function: Adds a driver to the System32 stack */
void install_shiny_driver(shiny_driver_t* driver) {
    if (driver == 0 || loaded_driver_count >= 256) {
        return; 
    }

    // Assign the driver to the stack
    driver_stack[loaded_driver_count] = driver;
    
    // Call the driver's 'load' function (The Vista-style Entry Point)
    if (driver->load != 0) {
        driver->load();
    }

    loaded_driver_count++;
}

/* Vista-style Power/Gloss Management:
   Enables high-performance mode for "Shiny" hardware.
*/
void set_driver_shiny_mode(uint32_t device_id, uint32_t level) {
    for (int i = 0; i < loaded_driver_count; i++) {
        if (driver_stack[i]->driver_id == device_id) {
            // Tell the specific hardware to enter Vista Gloss mode
            // This is where you trigger WDDM-style behavior
        }
    }
}

/* System32 Broadcast: Tells all drivers to unload during shutdown */
void unload_all_shiny_drivers() {
    for (int i = 0; i < loaded_driver_count; i++) {
        if (driver_stack[i]->unload != 0) {
            driver_stack[i]->unload();
        }
    }
    loaded_driver_count = 0;
}