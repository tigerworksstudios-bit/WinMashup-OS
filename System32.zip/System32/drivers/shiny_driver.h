#ifndef SHINY_DRIVER_H
#define SHINY_DRIVER_H

#include "../../../Kernel/kernel.h"

/* The Vista-style Driver Object */
typedef struct {
    char driver_name[64];
    uint32_t driver_id;
    void (*load)();
    void (*unload)();
} shiny_driver_t;

/* Function to register drivers with the Kernel */
void install_shiny_driver(shiny_driver_t* driver);

#endif