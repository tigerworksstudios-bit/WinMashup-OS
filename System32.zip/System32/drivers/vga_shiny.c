#include "vga_shiny.h"

/* Define the Driver Object for the System32 Manager */
shiny_driver_t vga_driver_info = {
    .driver_name = "Vista-Shiny VGA Driver",
    .driver_id = 0x1234,
    .load = vga_shiny_load,
    .unload = vga_shiny_unload
};

/* Implementation: Initialize the Hardware */
void vga_shiny_load() {
    // In a real OS, this would talk to the GPU registers
    // For Win Mashup, we ensure the LFB is ready for gloss
    for (int i = 0; i < (VGA_WIDTH * VGA_HEIGHT); i++) {
        LFB[i] = 0x000000; // Black screen boot
    }
}

/* Implementation: Draw with a "Shiny" Vista Border */
void vga_set_pixel(int x, int y, uint32_t color) {
    if (x >= VGA_WIDTH || y >= VGA_HEIGHT) return;

    // Direct write to the Kernel's Linear Frame Buffer
    LFB[y * VGA_WIDTH + x] = color;
}

void vga_shiny_unload() {
    // Clear memory before shutdown
    loaded_driver_count--;
}