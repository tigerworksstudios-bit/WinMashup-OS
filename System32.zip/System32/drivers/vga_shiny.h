#ifndef VGA_SHINY_H
#define VGA_SHINY_H

#include "shiny_driver.h"

/* VGA Hardware Definitions */
#define VGA_WIDTH  1024
#define VGA_HEIGHT 768

/* Driver Functions */
void vga_shiny_load();   // Wakes up the graphics card
void vga_shiny_unload(); // Shuts down the graphics card
void vga_set_pixel(int x, int y, uint32_t color);

/* The Global Driver Object */
extern shiny_driver_t vga_driver_info;

#endif