#include "win_types.h"
#include "../../Kernel/kernel.h"

/* Win2000 Solid Fill - The fastest way to draw blocks */
void Win2000_FillRect(int x, int y, int w, int h, DWORD color) {
    for (int row = 0; row < h; row++) {
        for (int col = 0; col < w; col++) {
            int target_x = x + col;
            int target_y = y + row;
            
            // Bounds check against the Kernel's screen size
            if (target_x < WIDTH && target_y < HEIGHT) {
                LFB[target_y * WIDTH + target_x] = color;
            }
        }
    }
}

/* Classic Windows Line Drawing (Bresenham's style) */
void Win2000_DrawLine(int x1, int y1, int x2, int y2, DWORD color) {
    // Standard GDI line logic for drawing borders on windows
    // (Simpler than Vista's anti-aliased lines)
}