#ifndef GDI32_H
#define GDI32_H

#include "win_types.h"

/* The Map of Windows 2000 Drawing Functions */
void Win2000_FillRect(int x, int y, int w, int h, DWORD color);
void Win2000_DrawLine(int x1, int y1, int x2, int y2, DWORD color);
void Win2000_SetPixel(int x, int y, DWORD color);

#endif