#include "taskbar.h"

void render_xp_taskbar() {
    int bar_h = 30;
    int start_y = HEIGHT - bar_h;

    // 1. Draw the Luna Blue Gradient Bar
    for (int y = 0; y < bar_h; y++) {
        uint32_t color = (y < 12) ? 0x4A8EFF : 0x245EDB; 
        for (int x = 0; x < WIDTH; x++) {
            LFB[(start_y + y) * WIDTH + x] = color;
        }
    }

    // 2. Draw the Green Start Button
    for (int y = 4; y < 26; y++) {
        for (int x = 5; x < 105; x++) {
            LFB[(start_y + y) * WIDTH + x] = 0x388E3C;
        }
    }
}

/* Draws an icon 'button' in a specific slot */
void draw_taskbar_icon(int slot, uint32_t color) {
    int start_y = HEIGHT - 26;
    // Position starts after Start Button (105px) + 10px padding
    int start_x = 115 + (slot * 165); 

    for (int y = 0; y < 22; y++) {
        for (int x = 0; x < 160; x++) {
            LFB[(start_y + y) * WIDTH + (start_x + x)] = color;
        }
    }
}