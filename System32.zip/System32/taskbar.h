#ifndef TASKBAR_H
#define TASKBAR_H

typedef unsigned int uint32_t;

/* External variables from the Kernel */
extern uint32_t* LFB;
extern int WIDTH;
extern int HEIGHT;

/* Functions for the Taskbar Shell */
void render_xp_taskbar();
void draw_taskbar_icon(int slot, uint32_t color);

#endif