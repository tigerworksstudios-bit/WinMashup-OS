#include "user32.h"

#define XP_LUNA_BLUE   0x245EDB  // The classic XP Blue
#define VISTA_GLOSS    0xFFFFFF  // Pure white for the shine

void DrawXPVistaWindow(HWND hwnd) {
    for (int i = 0; i < hwnd->height; i++) {
        for (int j = 0; j < hwnd->width; j++) {
            int px = hwnd->x + j;
            int py = hwnd->y + i;

            // Get what's currently on the screen (the background)
            uint32_t bg = LFB[py * WIDTH + px];

            // VISTA GLOSS LOGIC:
            // If we are in the top half of the window, add a 'reflection'
            uint32_t finalColor;
            if (i < 25) {
                // Top title bar: Blend XP Blue with Vista White Shine
                finalColor = (XP_LUNA_BLUE / 2) + (VISTA_GLOSS / 2);
            } else {
                // Window body: Blend XP Blue with the background (Transparency)
                finalColor = (XP_LUNA_BLUE / 2) + (bg / 2);
            }

            LFB[py * WIDTH + px] = finalColor;
        }
    }

    // Add the "Vista Line" - a 1-pixel white border at the very top
    Win2000_FillRect(hwnd->x, hwnd->y, hwnd->width, 1, VISTA_GLOSS);
}