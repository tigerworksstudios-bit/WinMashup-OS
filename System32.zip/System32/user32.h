#ifndef USER32_H
#define USER32_H

#include "win_types.h"
#include "gdi32.h"

/* XP Window Styles & Constants */
#define WS_VISIBLE       0x10000000
#define XP_TITLE_HEIGHT  28
#define VISTA_ALPHA_VAL  128  /* 50% Transparency */

/* * HWND (Handle to a Window) Structure
 * This tracks where the window is and how 'Shiny' it should be.
 */
typedef struct {
    int x;
    int y;
    int width;
    int height;
    LPCSTR lpWindowName;
    COLORREF baseColor;   /* Set this to XP_LUNA_BLUE */
    BOOL is_glossy;       /* Toggle for Vista Shine */
} HWND_STRUCT;

typedef HWND_STRUCT* HWND;

/* --- User32 Function Prototypes --- */

/* Basic Window Creation */
HWND CreateWindowXP(LPCSTR lpWindowName, int x, int y, int w, int h);

/* The Mashup Renderer: XP Blue meets Vista Gloss */
void DrawXPVistaWindow(HWND hwnd);

/* Standard User Interaction (Windows 2000/XP style) */
void MessageBoxXP(LPCSTR lpText, LPCSTR lpCaption);

#endif /* USER32_H */