#ifndef WIN_TYPES_H
#define WIN_TYPES_H

/* * Windows 2000 / NT 5.0 Core Type Definitions
 * These ensure that a 'DWORD' is always 32-bits, 
 * regardless of which driver is using it.
 */

/* Fixed-width integers */
typedef unsigned long       DWORD;   // 32-bit unsigned
typedef int                 BOOL;    // Integer used as boolean
typedef unsigned char       BYTE;    // 8-bit unsigned
typedef unsigned short      WORD;    // 16-bit unsigned
typedef float               FLOAT;   // 32-bit floating point
typedef unsigned int        UINT;    // System dependent unsigned int

/* Memory and Handles */
typedef void* HANDLE;  // Generic pointer to an object
typedef void* LPVOID;  // Logic Pointer to Void
typedef DWORD               COLORREF;// Windows color value (0x00BBGGRR)

/* Character types */
typedef char                CHAR;
typedef const char* LPCSTR;  // Long Pointer to Constant STRing

/* Logical Constants */
#define TRUE  1
#define FALSE 0

#ifndef NULL
#define NULL ((void *)0)
#endif

/* Calling Conventions for Win2000 compatibility */
#define WINAPI      __stdcall
#define CALLBACK    __stdcall

#endif /* WIN_TYPES_H */